const express = require("express");
const bodyParser = require("body-parser");
const sql = require("mssql");
const crypto = require("crypto");
require("dotenv").config();

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(express.static("public")); // Serve static frontend files (e.g., HTML, CSS, JS)

// SQL Database Configuration
const dbConfig = {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_SERVER,
    database: process.env.DB_DATABASE,
    options: {
        encrypt: true,
        enableArithAbort: true,
        connectTimeout: 30000,
        trustServerCertificate: true,
    },
};

// Utility function to connect to the database
const connectToDB = async () => {
    try {
        return await sql.connect(dbConfig);
    } catch (err) {
        console.error("Database connection error: ", err.message);
        throw new Error("Unable to connect to the database");
    }
};

// Route: Register Customer
app.post("/register", async (req, res) => {
    const { username, fullName, email, password } = req.body;

    if (!username || !fullName || !email || !password) {
        return res.status(400).send("All fields are required.");
    }

    // Hash the password using SHA-256
    const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");

    try {
        const pool = await connectToDB();
        await pool.request()
            .input("Username", sql.NVarChar, username)
            .input("FullName", sql.NVarChar, fullName)
            .input("Email", sql.NVarChar, email)
            .input("Password", sql.NVarChar, hashedPassword)
            .query(`INSERT INTO Customers (Username, FullName, Email, Password) VALUES (@Username, @FullName, @Email, @Password)`);
        res.status(201).send("Registration successful");
    } catch (err) {
        if (err.message.includes("Violation of UNIQUE KEY constraint")) {
            res.status(400).send("Username or email already exists.");
        } else {
            res.status(500).send("Error: " + err.message);
        }
    }
});


// Route: Customer Login
app.post("/login", async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).send("Username and password are required.");
    }

    try {
        const pool = await connectToDB();
        
        // Check if user exists
        const result = await pool.request()
            .input("Username", sql.NVarChar, username)
            .query("SELECT * FROM Customers WHERE Username = @Username");

        const user = result.recordset[0];
        const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");

        if (user && user.Password === hashedPassword) {
            // Log the login time
            const loginTime = new Date();
            await pool.request()
                .input("LoginTime", sql.DateTime, loginTime)
                .query("INSERT INTO LoginAuditTrail (LoginTime) VALUES (@LoginTime)");

            res.status(200).send("Login successful");
        } else {
            res.status(401).send("Invalid credentials");
        }
    } catch (err) {
        res.status(500).send("Error: " + err.message);
    }
});

// Route: Admin View
app.get("/admin", async (req, res) => {
    try {
        const pool = await connectToDB();
        const customers = await pool.request().query("SELECT CustomerID, Username, FullName, Email, CreatedAt FROM Customers");
        const reservations = await pool.request().query(`
            SELECT r.ReservationID, r.CustomerID, c.Username, c.FullName, r.ReservationDate, r.ReservationTime, r.NumberOfGuests, r.CreatedAt 
            FROM Reservations r
            JOIN Customers c ON r.CustomerID = c.CustomerID
        `);
        res.json({ customers: customers.recordset, reservations: reservations.recordset });
    } catch (err) {
        res.status(500).send("Error: " + err.message);
    }
});

// Route: Serve Dashboard Page
app.get("/dashboard", (req, res) => {
    res.sendFile(__dirname + "/public/dashboard.html");
});

// Route: Logout
app.get("/logout", (req, res) => {
    res.redirect("/home.html"); // Simply redirect to home page
});

// Handle 404 errors
app.use((req, res) => {
    res.status(404).send("Endpoint not found");
});

// Start the Server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}/home.html`);
});
